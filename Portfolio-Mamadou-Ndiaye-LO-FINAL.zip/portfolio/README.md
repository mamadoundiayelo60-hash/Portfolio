# Portfolio — Mamadou Ndiaye LO

Portfolio professionnel orienté recrutement dans les domaines de la géomatique, de la Data SIG et du développement Python/PostGIS.

## Projets présentés

- **GeoDashboard — Territorial Intelligence Studio** : aide à la décision territoriale, accessibilité et optimisation multicritère.
- **CoastProfile** : extension QGIS de création et de comparaison multiannuelle de profils côtiers GNSS.
- **CoastWatch** : suivi du trait de côte et analyse de l’érosion.
- **Pornic Agglo — Collecte des déchets** : application publique SIG développée pour une collectivité.
- **GeoCartoEngine** : galerie de neuf cartes réellement produites par le moteur d’analyse et de génération cartographique automatisée. Chaque livrable s’ouvre dans une visionneuse plein écran accessible au clavier.
- **Datavisualisations** : deux réalisations météo et spatio-temporelles réelles, affichées directement dans le portfolio.

## CV téléchargeable

Avant la publication, placez votre CV PDF dans le dossier `documents/` en conservant exactement ce nom :

Le CV final est inclus sous `documents/CV_Mamadou_Ndiaye_LO.pdf` et peut être téléchargé depuis l’en-tête ou la section contact.

Les deux boutons « Télécharger mon CV » pointeront alors automatiquement vers ce document.

## Publication sur GitHub Pages

1. Déposer le contenu de ce dossier à la racine du dépôt `Portfolio`.
2. Dans GitHub : **Settings → Pages**.
3. Choisir **Deploy from a branch**, branche `main`, dossier `/root`.
4. Enregistrer puis attendre la publication.

Le site ne nécessite aucune installation ni compilation.
